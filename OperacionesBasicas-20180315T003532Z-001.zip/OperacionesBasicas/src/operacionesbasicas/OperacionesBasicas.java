/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacionesbasicas;

/**
 *
 * @author Lilian
 */
public class OperacionesBasicas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         int Nu1=7,Nu2=4,Nu3=5,suma,resta,multi,divi,sum_rest,mult_sum;
         
         //SUMA
         suma=Nu1+Nu2;
         //RESTA
         resta=Nu1-Nu2;
         //MULTIPLICACION
         multi=Nu1*Nu2;
         //DIVICION
         divi=Nu1/Nu2;
         //ejemplo
         sum_rest= Nu1+Nu3-Nu2;
         //ejemplo2
         mult_sum=Nu1*Nu2+Nu3;
         
         
         System.out.println("El resultado es"+suma);
         System.out.println("El resultado es"+resta);
         System.out.println("El resultado es"+multi);
         System.out.println("El resultado es"+divi);
         System.out.println("El resultado es"+sum_rest);
         System.out.println("El resultado es"+mult_sum);
         
         
        // TODO code application logic here
    }
    
}
