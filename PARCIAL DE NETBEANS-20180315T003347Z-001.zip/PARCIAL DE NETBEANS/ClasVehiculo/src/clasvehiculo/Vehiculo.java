/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasvehiculo;

/**
 *
 * @author Lilian
 */
public class Vehiculo {
    private String color, placa;
    private int Num_llantas;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getNum_llantas() {
        return Num_llantas;
    }

    public void setNum_llantas(int Num_llantas) {
        this.Num_llantas = Num_llantas;
    }
}
