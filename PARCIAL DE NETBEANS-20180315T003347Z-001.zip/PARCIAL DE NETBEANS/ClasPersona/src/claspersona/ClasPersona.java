/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claspersona;

import jdk.nashorn.internal.codegen.CompilerConstants;

/**
 *
 * @author Lilian
 */
public class ClasPersona extends Persona{
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Docente1 obj= new Docente1();
        obj.setApellido("Ramirez");
        obj.setNombre("Juan");
        obj.setDocente("Estaban Jaramillo");
        obj.setCodigo(3002);
                 
        System.out.println(obj.getApellido());
        System.out.println(obj.getNombre());
        System.out.println(obj.getDocente());
        System.out.println(obj.getCodigo());
                              // TODO code application logic here
    }
    
}
