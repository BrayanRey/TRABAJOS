/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal;

/**
 *
 * @author Lilian
 */
public class Oviparo extends Animal{

    public String getPoner_Huevos() {
        return Poner_Huevos;
    }

    public void setPoner_Huevos(String Poner_Huevos) {
        this.Poner_Huevos = Poner_Huevos;
    }
    String Poner_Huevos;
}
