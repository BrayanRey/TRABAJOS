/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasvehiculo;

/**
 *
 * @author Lilian
 */
public class ClasVehiculo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carro obj =new Carro();
        obj.setColor("Rojo");
        obj.setPlaca("BMW");
        obj.setNum_llantas(4);
        obj.setModelo("modelo 2015");
        obj.setKilometros(5);
        
        System.out.println(obj.getColor());
        System.out.println(obj.getPlaca());
        System.out.println(obj.getNum_llantas());
        System.out.println(obj.getModelo());
        System.out.println(obj.getKilometros());
        // TODO code application logic here
    }
    
}
