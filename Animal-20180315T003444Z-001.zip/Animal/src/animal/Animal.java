/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal;

/**
 *
 * @author Lilian
 */
public class Animal {
    float Peso;
    String Comer;

    public float getPeso() {
        return Peso;
    }

    public void setPeso(float Peso) {
        this.Peso = Peso;
    }

    public String getComer() {
        return Comer;
    }

    public void setComer(String Comer) {
        this.Comer = Comer;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal Obj =new Animal();
        Obj.setPeso(8);
        Obj.setComer("Comida de la Granja");
                
            Oviparo Obj1 =new Oviparo();
            Obj1.setPoner_Huevos("Huevos de Igiana ocultos");
            
                Mamifero Obj2 =new Mamifero();
                Obj2.setParir("Proximamente Dos Animales");
                Obj2.setAmamantar("A los animales de la granja");
                
                    Delfin Obj3 =new Delfin();
                    Obj3.setDelfin("Nadar");
                    
                    Perro Obj4 =new Perro();
                    Obj4.setColor_Pelo("Amarillo");
                    Obj4.setLadrar("Un pastor aleman");
                    
        System.out.println(Obj.getPeso());
        System.out.println(Obj.getComer());
        
        System.out.println(Obj1.getPoner_Huevos());
        
        System.out.println(Obj2.getParir());
        System.out.println(Obj2.getAmamantar());
        
        System.out.println(Obj3.getDelfin());
        
        System.out.println(Obj4.getColor_Pelo());
        System.out.println(Obj4.getLadrar());
       
        // TODO code application logic here
    }
    
}
