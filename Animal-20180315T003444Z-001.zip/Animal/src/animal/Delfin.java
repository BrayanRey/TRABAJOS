/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal;

/**
 *
 * @author Lilian
 */
public class Delfin extends Mamifero{

    public String getDelfin() {
        return Delfin;
    }

    public void setDelfin(String Delfin) {
        this.Delfin = Delfin;
    }

    public boolean isSangre_Caliente() {
        return Sangre_Caliente;
    }

    public void setSangre_Caliente(boolean Sangre_Caliente) {
        this.Sangre_Caliente = Sangre_Caliente;
    }

    public String getParir() {
        return Parir;
    }

    public void setParir(String Parir) {
        this.Parir = Parir;
    }

    public String getAmamantar() {
        return Amamantar;
    }

    public void setAmamantar(String Amamantar) {
        this.Amamantar = Amamantar;
    }
    String Delfin;
}
